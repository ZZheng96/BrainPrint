# BrainPrint final submission

## 方法简述

训练免参数的几何模板匹配，不含神经网络：

1. 每条 18×1200 样本切成 6 个 200 点子窗。
2. 每个子窗用 FFT 掩码分成 5 个频带（1–8 / 8–13 / 13–20 / 20–30 / 30–40 Hz）。每个频带做通道标准化，计算 18×18 相关矩阵，按 0.05 收缩，取矩阵对数（logSPD），取上三角，非对角乘 √2。每个频带内对角去均值，再整体 z-score，得到 5×171 = 855 维向量。
3. 6 个子窗向量取平均。
4. 按任务（EC / EO / Imagery / SSVEP）做 z-score，然后投影到 PCA-96。
5. 计算到每个身份原型的欧氏距离。最近距离 ≤ τ = 19.263826 时输出该身份，否则判为未注册。

τ 取 Train 5 块 out-of-fold 最近原型距离的 90% 分位数，没有用任何测试数据或测试标签。

## 输入 / 输出

- `load_model(model_dir, device)`：只读取 `model_dir/weights.pt`（可用 `weights_only=True` 加载）。请求 `cuda:0` 但 CUDA 不可用时自动退回 CPU。
- `predict_batch(artifact, x, meta)`：x 为 float32 (N, 18, 1200)，N 取 1–128。返回 numpy float32 (N, 24)。
  - 第 0 列为 −τ（未注册）。
  - 第 c 列为 −(到身份 c 的距离)。
  - 未注册的新用户列为 −inf。
  - 输出不含 NaN，第 0 列始终有限。
  - 不修改 x，不读盘，不训练。
- `enroll(artifact, x, meta, labels)`：labels 取 21–23。返回更新后的 artifact。
- `meta`：如果每条 dict 含 `task` 字段（EC/EO/Imagery/SSVEP 或 Task1–4），就用对应任务的标准化。缺失或无法识别时，取四种任务标准化下的最小距离。不从文件名、路径或数据顺序推断任何信息。

## 训练数据来源和预处理

只用主办方 Train（20 人，session1，11,304 条）。任务标准化、PCA 和原型都用每个 subject×task 内前 60% 的试次拟合；τ 用 Train 内部 out-of-fold 距离确定。原始信号除 FFT 带通外不做其他预处理，通道顺序保持不变。

## 新用户注册方法

每名新用户的 20 条注册样本先提取 855 维特征。在每种任务的标准化与 PCA 下，把该用户所有样本投影后取均值，作为原型。为了增加样本数，所有任务的样本合并使用。注册不改变标准化统计量、PCA、τ 和原有 20 个原型，也就是不更新预训练权重。

## 本地运行 / 自测

```python
import sys; sys.path.insert(0, "brainprint")
import model
art = model.load_model("brainprint", "cuda:0")
art = model.enroll(art, x_enroll, meta_enroll, labels_enroll)   # labels in 21..23
scores = model.predict_batch(art, x, meta)                      # (N, 24)
pred = scores.argmax(1); pred[pred == 0] = -1
```

用 Train 模拟决赛流程（不在提交包内）：随机选 3 人作为新用户，从早期试次抽 20 条注册，在后 20% 试次上测试；另选 3 人作为未注册者，删除其原型；其余 14 人作为已注册用户，在后 20% 试次上测试。重复 20 次，结果为：

| 场景 | Train 模拟均值 | 最差一次 |
|---|---|---|
| 已注册用户识别（同会话） | 0.798 | – |
| 新用户注册后识别 | 0.803 | 0.625 |
| 未注册用户拒识 | 0.659 | 0.529 |

这些是同会话（session1）结果，而且 PCA 拟合时见过这些人，所以偏乐观。初赛 Test 中跨会话 S2 的 clean 准确率约为 0.71。

## 已知限制和失败情况

- **跨时段**：初赛 Test 跨会话 clean 准确率约 0.71，会话间漂移是主要误差来源。
- **跨设备**：只用单一设备训练，没有做设备适配。如果新设备的幅值或频响差异较大，距离会整体增大，更多样本会被拒识为 −1。
- **拒识与接受的权衡**：τ 固定后，拒识率与已注册用户接受率此消彼长。初赛 Test 未注册拒识约 0.71。
- **新用户**：只有 20 条注册样本，原型噪声较大。
- 依赖 `meta['task']`。缺失时退化为四种任务的最小距离，拒识率会略降。

## 依赖说明

只用 torch 和 numpy，均在官方环境（Python 3.10，torch 2.5.1+cu121，numpy 1.26.4）内。不用 scipy、pandas、自定义 CUDA 扩展，不联网，不启动子进程。
